# Glass Launcher
Home-screen launcher that draws every app icon as a liquid glass tile. Does not change Android itself.
1. Push this folder to a new GitHub repo.
2. Actions tab > Build APK > Run workflow (or it runs on push).
3. Download the GlassLauncher-apk artifact, unzip, install app-debug.apk.
4. Press Home and choose Glass Launcher > Always. To undo, pick your old launcher.
