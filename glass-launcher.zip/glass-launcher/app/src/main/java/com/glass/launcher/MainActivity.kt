package com.glass.launcher

import android.app.Activity
import android.content.Intent
import android.graphics.*
import android.graphics.drawable.AdaptiveIconDrawable
import android.graphics.drawable.ColorDrawable
import android.graphics.drawable.Drawable
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.animation.OvershootInterpolator
import android.widget.*
import java.util.concurrent.Executors

class MainActivity : Activity() {

    private class Item(val label: String, val icon: Bitmap, val intent: Intent)

    private val items = ArrayList<Item>()
    private lateinit var grid: GridView
    private val io = Executors.newSingleThreadExecutor()
    private val ui = Handler(Looper.getMainLooper())

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        grid = GridView(this).apply {
            numColumns = 4
            verticalSpacing = dp(20)
            stretchMode = GridView.STRETCH_COLUMN_WIDTH
            setPadding(dp(10), dp(56), dp(10), dp(32))
            clipToPadding = false
            selector = ColorDrawable(Color.TRANSPARENT)
            setBackgroundColor(0x33000000)
            adapter = Adapter()
            setOnItemClickListener { _, _, pos, _ -> startActivity(items[pos].intent) }
        }
        setContentView(grid)
    }

    override fun onResume() {
        super.onResume()
        loadApps()
    }

    @Deprecated("Launcher stays on home")
    override fun onBackPressed() {}

    private fun loadApps() {
        io.execute {
            val pm = packageManager
            val main = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
            val size = dp(60)
            val list = pm.queryIntentActivities(main, 0)
                .sortedBy { it.loadLabel(pm).toString().lowercase() }
                .map {
                    val launch = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
                        .setClassName(it.activityInfo.packageName, it.activityInfo.name)
                        .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                    Item(it.loadLabel(pm).toString(), glass(it.loadIcon(pm), size * 2), launch)
                }
            ui.post {
                items.clear(); items.addAll(list)
                (grid.adapter as BaseAdapter).notifyDataSetChanged()
            }
        }
    }

    /** Draws any app icon inside a frosted glass tile with a specular sheen and bright edge. */
    private fun glass(src: Drawable, s: Int): Bitmap {
        val bmp = Bitmap.createBitmap(s, s, Bitmap.Config.ARGB_8888)
        val c = Canvas(bmp)
        val f = s.toFloat()
        val inset = f * 0.03f
        val rect = RectF(inset, inset, f - inset, f - inset)
        val r = f * 0.28f
        val p = Paint(Paint.ANTI_ALIAS_FLAG)

        // frosted body
        p.shader = LinearGradient(0f, 0f, f, f,
            intArrayOf(0x70FFFFFF, 0x24FFFFFF, 0x48FFFFFF), null, Shader.TileMode.CLAMP)
        c.drawRoundRect(rect, r, r, p)

        // icon glyph, clipped to a soft rounded shape
        val g = f * 0.58f
        val gRect = RectF((f - g) / 2, (f - g) / 2, (f + g) / 2, (f + g) / 2)
        val d = src.constantState?.newDrawable()?.mutate() ?: src
        val full = if (d is AdaptiveIconDrawable) g * 108f / 72f else g
        val off = (f - full) / 2
        c.save()
        val clip = Path().apply { addRoundRect(gRect, g * 0.3f, g * 0.3f, Path.Direction.CW) }
        c.clipPath(clip)
        d.setBounds(off.toInt(), off.toInt(), (off + full).toInt(), (off + full).toInt())
        d.draw(c)
        c.restore()

        // top sheen
        val sheen = Paint(Paint.ANTI_ALIAS_FLAG)
        sheen.shader = LinearGradient(0f, 0f, 0f, f * 0.55f, 0x90FFFFFF.toInt(), 0x00FFFFFF, Shader.TileMode.CLAMP)
        c.drawRoundRect(RectF(inset * 2, inset * 2, f - inset * 2, f * 0.55f), r * 0.85f, r * 0.85f, sheen)

        // bright edge
        val edge = Paint(Paint.ANTI_ALIAS_FLAG)
        edge.style = Paint.Style.STROKE
        edge.strokeWidth = f * 0.022f
        edge.shader = LinearGradient(0f, 0f, f, f,
            intArrayOf(0xE0FFFFFF.toInt(), 0x14FFFFFF, 0x90FFFFFF.toInt()), null, Shader.TileMode.CLAMP)
        c.drawRoundRect(rect, r, r, edge)
        return bmp
    }

    private inner class Adapter : BaseAdapter() {
        override fun getCount() = items.size
        override fun getItem(i: Int) = items[i]
        override fun getItemId(i: Int) = i.toLong()
        override fun getView(i: Int, convert: View?, parent: ViewGroup): View {
            val it = items[i]
            val col = LinearLayout(this@MainActivity).apply {
                orientation = LinearLayout.VERTICAL
                gravity = Gravity.CENTER_HORIZONTAL
            }
            col.addView(ImageView(this@MainActivity).apply {
                setImageBitmap(it.icon)
                layoutParams = LinearLayout.LayoutParams(dp(60), dp(60))
            })
            col.addView(TextView(this@MainActivity).apply {
                text = it.label
                setTextColor(Color.WHITE)
                textSize = 11f
                maxLines = 1
                ellipsize = android.text.TextUtils.TruncateAt.END
                gravity = Gravity.CENTER
                setShadowLayer(6f, 0f, 2f, 0x99000000.toInt())
                setPadding(dp(2), dp(6), dp(2), 0)
            })
            col.setOnTouchListener { v, e ->
                when (e.action) {
                    MotionEvent.ACTION_DOWN -> v.animate().scaleX(.86f).scaleY(.86f).setDuration(120).start()
                    MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL ->
                        v.animate().scaleX(1f).scaleY(1f).setDuration(380)
                            .setInterpolator(OvershootInterpolator(3f)).start()
                }
                false
            }
            return col
        }
    }
}
